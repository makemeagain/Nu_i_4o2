<?
include("secret/start.php");
include("secret/session.php");
	if (isset($_SESSION['SID'])) {
		
	} else {
		header ('location: http://directolog-plus.ru/nui4o/index.php');
	}
$teacher = $_SESSION['fio'];
if(isset($_POST['entry'])) {
	if (!empty($_POST['phone']) && !empty($_POST['pass'])) {
		$str = trim($_POST['phone']);
		$phone = preg_replace('/[^0-9]/', '', $str);
		$pass = trim($_POST['pass']);

		$exists = "SELECT * FROM `Teacher` WHERE `phone` = '$phone' and `pass`='$pass' LIMIT 1";
		$ql = DB::query($exists);
		$check = DB::num_rows($ql);
		
		if ($check == 1) {
				$_SESSION['user_phone'] = $phone;
				$_SESSION['user_id'] = $id_sql;
				$_SESSION['SID'] = md5(crypt( $id_sql,$phone));
				$_SESSION['lastactivity'] = time();
				header ('location: http://directolog-plus.ru/nui4o/first.php');
		} else {
			header ('location: http://directolog-plus.ru/nui4o/error.php');
		}
	}
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Бально-рейтинговая система 1.0</title>

<meta name="description" content="Директолог+"/>
<meta name="keywords" content=""/>
<meta name="author" content="Ну и 4о">
<meta name="GENERATOR" content="Текстовый редактор">

<meta name="viewport" content="width=device-width, initial-scale=1" />

<script src="../js/jquery-3.1.1.js"></script>
<link rel="icon" href="favicon.ico" />
<link rel="shortcut icon" href="favicon.ico" />

<link href="css/st.css" rel="stylesheet">

<script src="js/jquery.maskedinput.js"></script>
<script type="text/javascript" charset="utf-8" src="../js/jquery.tubular.1.0.js"></script>
				<script type="text/javascript">
					jQuery(function($){
					   $('#phone').mask("+7 (999) 999-9999");
					   $('#phoneback').mask("+7 (999) 999-9999");
					});
				</script>
<link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
<!-- Yandex.Metrika counter --> <script type="text/javascript"> (function (d, w, c) { (w[c] = w[c] || []).push(function() { try { w.yaCounter45894603 = new Ya.Metrika({ id:45894603, clickmap:true, trackLinks:true, accurateTrackBounce:true, webvisor:true, trackHash:true }); } catch(e) { } }); var n = d.getElementsByTagName("script")[0], s = d.createElement("script"), f = function () { n.parentNode.insertBefore(s, n); }; s.type = "text/javascript"; s.async = false; s.src = "https://mc.yandex.ru/metrika/watch.js"; if (w.opera == "[object Opera]") { d.addEventListener("DOMContentLoaded", f, false); } else { f(); } })(document, window, "yandex_metrika_callbacks"); </script> <!-- /Yandex.Metrika counter -->
<!--[if lt IE 9]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
<!--[if lt IE 9]><script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script><![endif]-->

</head>

<body>
	<div class="obolochka">	
		<div class="centredv">
			<div class="block center">
				<div class="plitka">
					<div class="logoform">
						<div class="photo teacher" onclick="location.href = 'http://directolog-plus.ru/nui4o/index.php?exit=true';" id="exit">
						</div>
					</div>
					<div id="teacher" class="textfield"><?echo $teacher; ?></div>
				</div>
				<div class="plitka">
					<div class="logoform">
						<div class="photo groups">								
						</div>
					</div>
					<div class="textfield">ГРУППА</div>
				</div>					
				<div class="plitka">
					<div class="logoform">
						<div class="photo zhurnal">								
						</div>
					</div>
					<div class="textfield">ЖУРНАЛ</div>
				</div>
			</div>
		</div>
		
	</div>
</body>
</html>

<script type="text/javascript">
	/*$('#exit').click(function() {
	  $.ajax({
		type: "POST",
		url: "secret/obrabotka.php",
		data: ({ exit : true}),
		traditional: true,
		success: function(resp) {

		},
		error: function(resp) {
		  alert('Выход невозможен');
		}
	  });
	  return false;
	});*/
$("#exit").hover(function() {
	$('#exit').css('background-image','url(img/door.png)');
},function(){           
    $('#exit').css('background-image','url(img/teacher.png)');
        })	
</script>