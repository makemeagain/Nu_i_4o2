<?php
include("tmpl/session.php");
include("conf/start.php");

if(!empty($_POST))
{	
	if  (isset($_POST['exit'])){
		location.href = 'http://directolog-plus.ru/nui4o/index.php';
		session_unset();
		session_destroy();		
	}
}
?>