<?php
header("http/1.0 200 Ok");
//header('Content-Type: text/html; charset=utf-8');
require 'class.db.php';
$conf = parse_ini_file('config.ini');
define('HOST', $conf['mysql_host']); //сервер
define('USER', $conf['mysql_user']); //пользователь
define('PASSWORD', $conf['mysql_password']); //пароль
define('NAME_BD', $conf['mysql_database']);//база  

DB::getInstance();
?>