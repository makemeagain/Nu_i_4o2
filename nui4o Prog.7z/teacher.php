<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Вход на сайт</title>

<meta name="description" content="Директолог+"/>
<meta name="keywords" content=""/>
<meta name="author" content="Ну и 4о">
<meta name="GENERATOR" content="Текстовый редактор">

<meta name="viewport" content="width=device-width, initial-scale=1" />

<script src="../js/jquery-3.1.1.js"></script>
<link rel="icon" href="favicon.ico" />
<link rel="shortcut icon" href="favicon.ico" />

<link href="css/st.css" rel="stylesheet">

<script src="js/jquery.maskedinput.js"></script>
<script type="text/javascript" charset="utf-8" src="../js/jquery.tubular.1.0.js"></script>
				<script type="text/javascript">
					jQuery(function($){
					   $('#phone').mask("+7 (999) 999-9999");
					   $('#phoneback').mask("+7 (999) 999-9999");
					});
				</script>
<link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
<!-- Yandex.Metrika counter --> <script type="text/javascript"> (function (d, w, c) { (w[c] = w[c] || []).push(function() { try { w.yaCounter45894603 = new Ya.Metrika({ id:45894603, clickmap:true, trackLinks:true, accurateTrackBounce:true, webvisor:true, trackHash:true }); } catch(e) { } }); var n = d.getElementsByTagName("script")[0], s = d.createElement("script"), f = function () { n.parentNode.insertBefore(s, n); }; s.type = "text/javascript"; s.async = false; s.src = "https://mc.yandex.ru/metrika/watch.js"; if (w.opera == "[object Opera]") { d.addEventListener("DOMContentLoaded", f, false); } else { f(); } })(document, window, "yandex_metrika_callbacks"); </script> <!-- /Yandex.Metrika counter -->
<!--[if lt IE 9]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
<!--[if lt IE 9]><script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script><![endif]-->
</head>

<body>
<div class="obolochka">
	<div class="centredv">
		<div class="block">
			<div class="centredh">
				<div class="inline">
					<div class="logoform"></div>
					<form method="post" class="forma">
						<div class="marginh">
							<input name="phone" type="text" placeholder="Фамилия Имя Отчество">
						</div>
						<div class="marginh">
							<input name="phone" type="text" placeholder="Телефон">
						</div>
						<div class="marginh">
							<input name="pass" type="text" placeholder="Пароль">
						</div>
						<div class="marginh">
							<button class="hidden" type="submit" name="entry">Добавить</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
</body>
</html>